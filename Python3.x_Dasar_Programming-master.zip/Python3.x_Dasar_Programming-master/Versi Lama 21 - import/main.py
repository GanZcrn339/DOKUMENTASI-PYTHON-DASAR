import modul

print(modul.data)

modul.cek_modul()