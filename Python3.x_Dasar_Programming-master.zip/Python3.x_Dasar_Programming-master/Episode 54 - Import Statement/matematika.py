def tambah(a:float,b:float)->float:
    return a+b