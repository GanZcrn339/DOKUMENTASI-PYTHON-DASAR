from . import matematika
from . import pisika

# __all__ = [
#     "matematika",
#     "pisika"
# ]