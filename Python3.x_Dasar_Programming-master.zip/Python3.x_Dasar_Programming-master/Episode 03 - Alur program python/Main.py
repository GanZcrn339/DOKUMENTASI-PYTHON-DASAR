import time
start_time = time.time()

print("Hello")
print("World")
print("Hello World")

print("Halo Chantiiek")
# ini adalah comment
a = 10 # ini adalah comment juga
"""ada apa dengan
ucup dan otong si ganteng
dalam comment multiline"""
print(a)
print(time.time() - start_time, "detik")
# kita bisa mengcompile python ke
# yang namanya bytecode
# cara mengcompile, buka terminal dan tuliskan
# python -m py_compile Main.py