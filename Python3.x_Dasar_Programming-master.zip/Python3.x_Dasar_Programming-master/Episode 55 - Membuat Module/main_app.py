# module matematika dengan import

import matematika

hasil_tambah = matematika.tambah(1,2,3,4,5)
print(f"hasil tambah = {hasil_tambah}")

hasil_kali = matematika.kali(1,2,3,4,5)
print(f"hasil tambah = {hasil_kali}")

pangkat_3 = matematika.pangkat(3)
print(f"hasil pangkat3 = {pangkat_3(3)}")