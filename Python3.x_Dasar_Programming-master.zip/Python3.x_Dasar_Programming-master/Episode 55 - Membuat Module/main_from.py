# module matematika dengan import

from matematika import tambah,kali,pangkat
# from matematika import *

hasil_tambah = tambah(1,2,3,4,5)
print(f"hasil tambah = {hasil_tambah}")

hasil_kali = kali(1,2,3,4,5)
print(f"hasil tambah = {hasil_kali}")

pangkat_3 = pangkat(3)
print(f"hasil pangkat3 = {pangkat_3(3)}")