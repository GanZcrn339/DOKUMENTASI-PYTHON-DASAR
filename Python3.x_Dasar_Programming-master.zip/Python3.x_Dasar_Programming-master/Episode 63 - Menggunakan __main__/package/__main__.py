print("ini adalah main dari package")
print("package ini berfungsi untuk")
print(f"nilai __name__ = '{__name__}'")