# list
# menggunakan kurung siku
data_list = [10,2,4,3,2] 
print(data_list)

# tuples
data_tuples = (7,8,9,10)
print(data_tuples)
print(data_tuples[1])

# tidak bisa dilakukan
# data_tuples[1] = "ucup"
# data_tuples.append(1)

# sets (himpunan)
data_sets = {10,4,3,2,4,7,6,5}
print(data_sets)

print(data_sets[0])