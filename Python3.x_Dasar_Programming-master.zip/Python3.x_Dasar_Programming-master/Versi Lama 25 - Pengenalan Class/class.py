class Mahasiswa():
	nama = 'nama'

otong = Mahasiswa()
ucup = Mahasiswa()

otong.nama = "otong surotong"
ucup.nama = "michael ucup"

print(otong.nama)
print(ucup.nama)