a = 5
b = 3

# penjumlahan
c = a + b
print("hasil a + b = ", c)

# pengurangan
c = a - b
print("hasil a - b = ", c)

# perkalian
c = a*b
print("hasil a*b = ", c)

# pembagian
c = a / b
print("hasil a/b =", c)

# pembagian pembulatan keatas



# modulus

# pangkat




