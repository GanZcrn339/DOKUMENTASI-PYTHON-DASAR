from .Database import init_console
from .View import read_console,create_console