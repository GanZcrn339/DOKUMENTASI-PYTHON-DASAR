a = 5
b = 3
c = 4.0

# penjumlahan

print("penjumlahan a + b = ", a + b)

# pengurangan

print("pengurangan a - b = ", a - b)

# perkalian

print("perkalian a * b = ", a * b)

# pembagian

print("pembagian a / b = ", a / b)

