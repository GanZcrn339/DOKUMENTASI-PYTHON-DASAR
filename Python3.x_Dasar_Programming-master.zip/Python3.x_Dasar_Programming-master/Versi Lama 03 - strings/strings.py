text1 = 'jalan - jalan di hari minggu'

text2 = 'jalan - jalan di hari jum\'at'

text3 = "jalan - jalan di hari jum'at"

text4 = 'mahmuy berkata, "kemaren kemana bro?"'

text5 = "hobloh menjawab, \"jalan - jalan bro\" "

text6 = 'mahmuy: "kemaren kemana bro?" \nhobloh: "jalan - jalan bro"'

text7 = """
mahmuy: "kemaren kemana bro?"
hobloh: "jalan - jalan bro"
mahmuy: "jalan - jalan kemana bro?"
hobloh: "ke Mang Uing bro!!!!"
"""

text8 = r'C:\nyoto' # raw string

print(text8)
print(5*"wk")
print('kue' 'pukis')
print(text1 + text2)
