def tambah(a,b):
    print('fungsi tambah')
    print(a,'+',b,'=',a+b)

def kurang(a,b):
    print('fungsi kurang')
    print(a,'-',b,'=',a-b)