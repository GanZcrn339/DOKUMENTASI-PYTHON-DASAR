#import matematika

# matematika.tambah(3,4)
# matematika.kurang(4,5)

# import matematika as m
#
# m.tambah(3,4)
# m.kurang(5,4)

# from matematika import tambah, kurang
# from matematika import *

# tambah(4,5)
# kurang(5,4)

from matematika import tambah as t

t(3,4)