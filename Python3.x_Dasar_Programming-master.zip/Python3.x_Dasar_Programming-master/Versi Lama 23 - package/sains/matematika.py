def tambah(a, b):
    print('fungsi tambah')
    return a + b


def kurang(a, b):
    print('fungsi kurang')
    return a - b